function showInfo() {
	document.getElementById('show-numero').style.display = "none";
	document.getElementById('show-orario').style.display = "none";
	document.getElementById('show-email').style.display = "none";
   document.getElementById('show-indirizzo').style.display = "block";
}

function showNum() {
	document.getElementById('show-indirizzo').style.display = "none";
	document.getElementById('show-orario').style.display = "none";
	document.getElementById('show-email').style.display = "none";
   document.getElementById('show-numero').style.display = "block";
}

function showTime() {
	document.getElementById('show-numero').style.display = "none";
	document.getElementById('show-indirizzo').style.display = "none";
	document.getElementById('show-email').style.display = "none";
   document.getElementById('show-orario').style.display = "block";
}

function showEmail() {
	document.getElementById('show-numero').style.display = "none";
	document.getElementById('show-orario').style.display = "none";
	document.getElementById('show-indirizzo').style.display = "none";
   document.getElementById('show-email').style.display = "block";
}

